# Simple E-commerce Store (Django)

A beginner-friendly e-commerce project built with HTML, CSS, JavaScript, Python/Django, and SQLite.

## Features
- Product listing and product detail pages
- User registration, login, and logout
- Shopping cart (stored in the user's session)
- Checkout and order processing
- Database models for products, users (Django's built-in User), orders, and order items
- Django admin for managing products and viewing orders

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this project folder.
3. Create and activate a virtual environment:

   **Windows**
   ```bash
   py -m venv venv
   venv\Scripts\activate
   ```

   **macOS/Linux**
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

4. Install Django:
   ```bash
   pip install -r requirements.txt
   ```
5. Create the database tables:
   ```bash
   python manage.py migrate
   ```
6. Add sample products:
   ```bash
   python manage.py seed_products
   ```
7. Start the website:
   ```bash
   python manage.py runserver
   ```
8. Open http://127.0.0.1:8000/ in your browser.

## Admin
Create an administrator:
```bash
python manage.py createsuperuser
```
Then visit http://127.0.0.1:8000/admin/ to add/edit products and review orders.

## Project structure
```text
simple_ecommerce_store/
├── manage.py
├── requirements.txt
├── store_project/
├── shop/
│   ├── management/commands/seed_products.py
│   ├── migrations/
│   ├── templates/shop/
│   └── static/shop/
└── README.md
```

This is an educational demo. For a real store, add payment-gateway integration, production security settings, image storage, shipping, and deployment configuration.
