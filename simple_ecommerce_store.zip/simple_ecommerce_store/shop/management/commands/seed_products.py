from django.core.management.base import BaseCommand
from shop.models import Product

class Command(BaseCommand):
    help = "Add sample products to the store"

    def handle(self, *args, **options):
        samples = [
            ("Wireless Headphones", "Comfortable wireless headphones for everyday listening.", "1499.00", "https://images.unsplash.com/photo-150/>", 15),
            ("Smart Watch", "A smart watch with useful everyday features.", "2299.00", "", 12),
            ("Backpack", "A lightweight backpack for college and travel.", "999.00", "", 20),
            ("Sports Shoes", "Comfortable shoes for walking and daily use.", "1799.00", "", 10),
        ]
        for name, description, price, image_url, stock in samples:
            Product.objects.get_or_create(name=name, defaults={
                "description": description, "price": price,
                "image_url": image_url if image_url.startswith("http") else "",
                "stock": stock
            })
        self.stdout.write(self.style.SUCCESS("Sample products are ready."))
