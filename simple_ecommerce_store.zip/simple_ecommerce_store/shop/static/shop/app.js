// Small frontend interaction: confirm before placing an order.
document.addEventListener("DOMContentLoaded", () => {
  const checkoutForm = document.querySelector(".checkout-layout form");
  if (checkoutForm) {
    checkoutForm.addEventListener("submit", (event) => {
      if (!window.confirm("Place this order now?")) event.preventDefault();
    });
  }
});
