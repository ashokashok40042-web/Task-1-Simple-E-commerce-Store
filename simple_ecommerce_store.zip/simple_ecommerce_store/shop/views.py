from decimal import Decimal
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from .forms import RegisterForm, CheckoutForm
from .models import Product, Order, OrderItem

def product_list(request):
    products = Product.objects.all()
    return render(request, "shop/product_list.html", {"products": products})

def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    return render(request, "shop/product_detail.html", {"product": product})

def register(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Your account has been created.")
            return redirect("product_list")
    else:
        form = RegisterForm()
    return render(request, "shop/register.html", {"form": form})

def _cart_items(request):
    cart = request.session.get("cart", {})
    items, total = [], Decimal("0.00")
    for product_id, quantity in cart.items():
        product = Product.objects.filter(pk=product_id).first()
        if product:
            line_total = product.price * quantity
            items.append({"product": product, "quantity": quantity, "line_total": line_total})
            total += line_total
    return items, total

def cart_detail(request):
    items, total = _cart_items(request)
    return render(request, "shop/cart.html", {"items": items, "total": total})

def cart_add(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    cart = request.session.get("cart", {})
    current = int(cart.get(str(product_id), 0))
    if current < product.stock:
        cart[str(product_id)] = current + 1
        request.session["cart"] = cart
        messages.success(request, f"{product.name} added to your cart.")
    else:
        messages.error(request, "Sorry, there is not enough stock.")
    return redirect(request.META.get("HTTP_REFERER", "product_list"))

def cart_remove(request, product_id):
    cart = request.session.get("cart", {})
    cart.pop(str(product_id), None)
    request.session["cart"] = cart
    messages.info(request, "Item removed from your cart.")
    return redirect("cart_detail")

@login_required
def checkout(request):
    items, total = _cart_items(request)
    if not items:
        messages.info(request, "Your cart is empty.")
        return redirect("product_list")
    if request.method == "POST":
        form = CheckoutForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                # Recheck stock before saving the order.
                for item in items:
                    product = Product.objects.select_for_update().get(pk=item["product"].pk)
                    if product.stock < item["quantity"]:
                        messages.error(request, f"Not enough stock for {product.name}.")
                        return redirect("cart_detail")
                order = Order.objects.create(
                    user=request.user,
                    full_name=form.cleaned_data["full_name"],
                    phone=form.cleaned_data["phone"],
                    address=form.cleaned_data["address"],
                    total=total,
                )
                for item in items:
                    product = Product.objects.select_for_update().get(pk=item["product"].pk)
                    OrderItem.objects.create(
                        order=order, product=product,
                        quantity=item["quantity"], price_at_purchase=product.price
                    )
                    product.stock -= item["quantity"]
                    product.save(update_fields=["stock"])
            request.session["cart"] = {}
            messages.success(request, f"Order #{order.pk} placed successfully!")
            return redirect("order_history")
    else:
        form = CheckoutForm()
    return render(request, "shop/checkout.html", {"form": form, "items": items, "total": total})

@login_required
def order_history(request):
    orders = Order.objects.filter(user=request.user).prefetch_related("items__product")
    return render(request, "shop/orders.html", {"orders": orders})
